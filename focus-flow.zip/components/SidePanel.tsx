
import React, { useState, useRef, useEffect } from 'react';
import { X, Palette, Layout, Columns, Rows, Film, Download, Music, Mic, Play, Trash2, MoreVertical, Check, Loader2 } from 'lucide-react';
import { Theme, THEME_STYLES, ThemeColors, SplitDirection, RecordedSession } from '../types';

interface SidePanelProps {
  isOpen: boolean;
  onClose: () => void;
  currentTheme: Theme;
  onThemeChange: (theme: Theme) => void;
  colors: ThemeColors;
  isSplitScreen: boolean;
  onToggleSplitScreen: () => void;
  splitDirection: SplitDirection;
  onDirectionChange: (direction: SplitDirection) => void;
  sessions: RecordedSession[];
  onDeleteSession: (id: string) => void;
}

const GalleryItem: React.FC<{ session: RecordedSession; colors: ThemeColors; onDelete: (id: string) => void }> = ({ session, colors, onDelete }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  // Export State
  const [exportSpeed, setExportSpeed] = useState(2); // Default 2x
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowSpeedMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handlePlay = () => {
    if (!videoSrc) {
      // Prefer mixed blob if available, else raw
      const blob = session.mixedBlob || session.rawBlob;
      const url = URL.createObjectURL(blob);
      setVideoSrc(url);
    }
    setIsPlaying(true);
  };

  const handleVideoLoad = (e: React.SyntheticEvent<HTMLVideoElement>) => {
    // Playback at 2x by default for preview
    e.currentTarget.playbackRate = 2.0;
    e.currentTarget.play();
  };

  const downloadBlob = (blob: Blob, filename: string) => {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
  };

  const processAndDownload = async (blob: Blob | null, type: 'raw' | 'mixed') => {
    if (!blob) return;

    // If 1x, direct download (Instant)
    if (exportSpeed === 1) {
        downloadBlob(blob, `focus-flow-${type}-${session.id}-1x.webm`);
        return;
    }

    setIsProcessing(true);
    try {
        const video = document.createElement('video');
        video.src = URL.createObjectURL(blob);
        video.crossOrigin = 'anonymous'; 
        video.muted = false; // Need this false to capture audio track, though we mute output locally
        
        // Wait for metadata
        await new Promise((resolve) => {
            video.onloadedmetadata = () => resolve(true);
        });

        // Use captureStream to record the accelerated playback
        // Note: 'captureStream' is standard but sometimes prefixed or missing in types
        const stream = (video as any).captureStream ? (video as any).captureStream() : (video as any).mozCaptureStream();
        
        const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
        const chunks: Blob[] = [];

        recorder.ondataavailable = (e) => {
            if (e.data.size > 0) chunks.push(e.data);
        };

        recorder.onstop = () => {
            const newBlob = new Blob(chunks, { type: 'video/webm' });
            downloadBlob(newBlob, `focus-flow-${type}-${session.id}-${exportSpeed}x.webm`);
            setIsProcessing(false);
            URL.revokeObjectURL(video.src);
            video.remove();
        };

        recorder.start();
        
        // Set speed and play
        video.playbackRate = exportSpeed;
        video.play().catch(e => console.error("Auto-play failed during export", e));

        video.onended = () => {
            recorder.stop();
        };

        // Fallback safety: If video stalls or onended misses
        video.onerror = () => {
             recorder.stop();
             alert("Error processing video.");
        };

    } catch (e) {
        console.error("Export failed", e);
        alert("Export failed (Browser might not support captureStream). Downloading original.");
        downloadBlob(blob, `focus-flow-${type}-${session.id}-original.webm`);
        setIsProcessing(false);
    }
  };

  return (
    <div className={`rounded-xl overflow-hidden border ${colors.border} ${colors.cardBg} shadow-lg transition-all hover:shadow-xl relative group`}>
      <div className="relative aspect-video bg-black">
        {isPlaying && videoSrc ? (
          <video
            ref={videoRef}
            src={videoSrc}
            className="w-full h-full object-contain"
            controls
            onLoadedMetadata={handleVideoLoad}
            onEnded={() => setIsPlaying(false)}
          />
        ) : (
          <>
            <img src={session.thumbnailUrl} alt="Thumbnail" className="w-full h-full object-cover opacity-80 group-hover:opacity-60 transition-opacity" />
            <button 
              onClick={handlePlay}
              className="absolute inset-0 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            >
              <div className="bg-white/20 backdrop-blur-sm p-4 rounded-full shadow-xl hover:scale-110 transition-transform">
                <Play size={32} fill="currentColor" />
              </div>
            </button>
            <div className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 rounded text-white text-xs font-mono pointer-events-none">
              {Math.floor(session.duration / 60)}:{(session.duration % 60).toString().padStart(2, '0')}
            </div>
            <div className="absolute top-2 left-2 bg-black/70 px-2 py-1 rounded text-white text-xs pointer-events-none">
              {new Date(session.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
            </div>
            <div className="absolute top-2 right-2 bg-rose-600/90 px-2 py-1 rounded text-white text-[10px] font-bold uppercase tracking-wider shadow-sm pointer-events-none">
              2x Speed
            </div>
          </>
        )}
      </div>
      
      <div className="p-3 space-y-3 relative">
        {isProcessing ? (
             <div className="flex items-center justify-center py-2 space-x-2 text-xs font-bold animate-pulse text-blue-500">
                 <Loader2 size={16} className="animate-spin" />
                 <span>Processing Time Lapse ({exportSpeed}x)...</span>
             </div>
        ) : (
            <div className="flex items-center justify-between gap-2">
            {/* Raw Download */}
            <button 
                onClick={() => processAndDownload(session.rawBlob, 'raw')}
                className={`flex-1 flex items-center justify-center px-2 py-2 rounded-lg text-[10px] sm:text-xs font-bold border ${colors.border} hover:bg-black/5 transition ${colors.text} truncate`}
                title={`Download with Microphone Audio only (${exportSpeed}x)`}
            >
                <Mic size={14} className="mr-1.5 flex-shrink-0" /> 
                <span className="truncate">No Bg ({exportSpeed}x)</span>
            </button>
            
            {/* Mixed Download */}
            <button 
                onClick={() => processAndDownload(session.mixedBlob, 'mixed')}
                disabled={!session.mixedBlob}
                className={`flex-1 flex items-center justify-center px-2 py-2 rounded-lg text-[10px] sm:text-xs font-bold ${colors.accent} text-white hover:opacity-90 transition disabled:opacity-50 disabled:cursor-not-allowed truncate`}
                title={`Download with Background Noise (${exportSpeed}x)`}
            >
                <Music size={14} className="mr-1.5 flex-shrink-0" /> 
                <span className="truncate">With Bg ({exportSpeed}x)</span>
            </button>

            {/* Speed Menu Trigger */}
            <div className="relative" ref={menuRef}>
                <button
                    onClick={() => setShowSpeedMenu(!showSpeedMenu)}
                    className={`p-2 rounded-lg border ${colors.border} hover:bg-black/5 transition ${colors.text}`}
                >
                    <MoreVertical size={16} />
                </button>

                {/* Speed Dropdown */}
                {showSpeedMenu && (
                    <div className={`absolute bottom-full right-0 mb-2 w-32 ${colors.cardBg} border ${colors.border} rounded-xl shadow-xl overflow-hidden z-20 animate-fade-in`}>
                        <div className={`px-3 py-2 text-[10px] font-bold uppercase opacity-50 border-b ${colors.border} ${colors.text}`}>
                            Export Speed
                        </div>
                        {[1, 2, 3, 4, 5].map(speed => (
                            <button
                                key={speed}
                                onClick={() => { setExportSpeed(speed); setShowSpeedMenu(false); }}
                                className={`w-full text-left px-3 py-2 text-xs font-medium flex items-center justify-between hover:bg-black/5 transition ${colors.text} ${exportSpeed === speed ? 'bg-black/5' : ''}`}
                            >
                                <span>{speed}x Speed</span>
                                {exportSpeed === speed && <Check size={12} />}
                            </button>
                        ))}
                    </div>
                )}
            </div>
            </div>
        )}
        
        <div className="flex items-center justify-between">
           {!session.mixedBlob && (
             <span className="text-[10px] opacity-60 italic">Bg sound off</span>
           )}
           <button
             onClick={() => onDelete(session.id)}
             disabled={isProcessing}
             className="ml-auto p-2 text-red-500 hover:bg-red-100 rounded-full transition disabled:opacity-30"
             title="Delete Recording"
           >
             <Trash2 size={16} />
           </button>
        </div>
      </div>
    </div>
  );
};

export const SidePanel: React.FC<SidePanelProps> = ({
  isOpen,
  onClose,
  currentTheme,
  onThemeChange,
  colors,
  isSplitScreen,
  onToggleSplitScreen,
  splitDirection,
  onDirectionChange,
  sessions,
  onDeleteSession
}) => {
  const [activeTab, setActiveTab] = useState<'settings' | 'gallery'>('settings');
  
  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 transition-opacity"
          onClick={onClose}
        />
      )}

      {/* Panel */}
      <div className={`fixed top-0 right-0 h-full w-96 max-w-[90vw] ${colors.secondaryBg} shadow-2xl transform transition-transform duration-500 cubic-bezier(0.4, 0, 0.2, 1) z-50 ${isOpen ? 'translate-x-0' : 'translate-x-full'} border-l ${colors.border} flex flex-col`}>
        
        <div className={`p-4 border-b ${colors.border} flex justify-between items-center flex-shrink-0`}>
           {/* Tabs */}
           <div className="flex space-x-1 bg-black/10 p-1 rounded-lg">
              <button 
                onClick={() => setActiveTab('settings')}
                className={`px-4 py-1.5 rounded-md text-xs font-bold uppercase tracking-wide transition-all ${activeTab === 'settings' ? 'bg-white shadow text-black' : `${colors.text} opacity-60 hover:opacity-100`}`}
              >
                Settings
              </button>
              <button 
                onClick={() => setActiveTab('gallery')}
                className={`px-4 py-1.5 rounded-md text-xs font-bold uppercase tracking-wide transition-all ${activeTab === 'gallery' ? 'bg-white shadow text-black' : `${colors.text} opacity-60 hover:opacity-100`}`}
              >
                Gallery
              </button>
           </div>

          <button onClick={onClose} className={`${colors.text} hover:scale-110 transition`}>
            <X size={24} />
          </button>
        </div>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-8">
          
          {/* SETTINGS TAB */}
          {activeTab === 'settings' && (
            <div className="space-y-8 animate-slide-up">
              {/* Layout Section */}
              <section>
                <h3 className={`text-xs uppercase tracking-wider font-bold ${colors.text} opacity-60 mb-4 flex items-center`}>
                  <Layout size={14} className="mr-2" /> Layout Options
                </h3>
                
                {/* Toggle Split Screen */}
                <div className={`flex items-center justify-between p-4 rounded-xl ${colors.cardBg} border ${colors.border} mb-4 shadow-sm`}>
                  <span className={`text-sm font-medium ${colors.text}`}>Show Camera</span>
                  <button 
                    onClick={onToggleSplitScreen}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 ${isSplitScreen ? 'bg-green-500' : 'bg-gray-400'}`}
                  >
                    <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-300 ${isSplitScreen ? 'translate-x-6' : 'translate-x-1'}`} />
                  </button>
                </div>

                {/* Split Direction */}
                <div className={`transition-all duration-500 ${isSplitScreen ? 'opacity-100 h-auto' : 'opacity-50 pointer-events-none grayscale'}`}>
                  <p className={`text-xs mb-3 ${colors.text} opacity-70 font-medium`}>Split Orientation</p>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => onDirectionChange('horizontal')}
                      className={`p-3 rounded-xl border-2 flex flex-col items-center justify-center transition-all duration-300 ${
                        splitDirection === 'horizontal' 
                          ? `${colors.accent} text-white border-transparent shadow-md scale-105` 
                          : `${colors.cardBg} ${colors.text} ${colors.border} hover:border-gray-400`
                      }`}
                    >
                      <Columns size={24} className="mb-2" />
                      <span className="text-xs font-medium">Side by Side</span>
                    </button>
                    <button
                      onClick={() => onDirectionChange('vertical')}
                      className={`p-3 rounded-xl border-2 flex flex-col items-center justify-center transition-all duration-300 ${
                        splitDirection === 'vertical' 
                          ? `${colors.accent} text-white border-transparent shadow-md scale-105` 
                          : `${colors.cardBg} ${colors.text} ${colors.border} hover:border-gray-400`
                      }`}
                    >
                      <Rows size={24} className="mb-2" />
                      <span className="text-xs font-medium">Stacked</span>
                    </button>
                  </div>
                </div>
              </section>

              {/* Theme Section */}
              <section>
                <h3 className={`text-xs uppercase tracking-wider font-bold ${colors.text} opacity-60 mb-4 flex items-center`}>
                  <Palette size={14} className="mr-2" /> Color Themes
                </h3>
                <div className="grid grid-cols-1 gap-3">
                  {(Object.keys(THEME_STYLES) as Theme[]).map((themeName) => (
                    <button
                      key={themeName}
                      onClick={() => onThemeChange(themeName)}
                      className={`flex items-center p-3 rounded-xl border-2 transition-all duration-300 ${
                        currentTheme === themeName 
                          ? `border-current ring-1 ring-offset-1 ring-current shadow-md scale-[1.02]` 
                          : 'border-transparent hover:bg-black/5'
                      } ${THEME_STYLES[themeName].cardBg} ${THEME_STYLES[themeName].text}`}
                    >
                      <div className={`w-8 h-8 rounded-full mr-3 border ${THEME_STYLES[themeName].border} shadow-inner`} style={{ background: 'linear-gradient(135deg, currentColor 50%, transparent 50%)' }}></div>
                      <span className="text-sm font-semibold">
                        {themeName.replace(/([A-Z])/g, ' $1').trim()}
                      </span>
                    </button>
                  ))}
                </div>
              </section>
            </div>
          )}

          {/* GALLERY TAB */}
          {activeTab === 'gallery' && (
            <div className="space-y-6 animate-slide-up">
                 <h3 className={`text-xs uppercase tracking-wider font-bold ${colors.text} opacity-60 flex items-center`}>
                  <Film size={14} className="mr-2" /> Recorded Sessions
                </h3>

                {sessions.length === 0 ? (
                    <div className={`p-8 rounded-xl border-dashed border-2 ${colors.border} flex flex-col items-center justify-center text-center opacity-50`}>
                        <Film size={32} className={`mb-2 ${colors.text}`} />
                        <p className={`text-sm ${colors.text}`}>No recordings yet.</p>
                        <p className="text-xs mt-1">Record a session to see it here.</p>
                    </div>
                ) : (
                    sessions.map(session => (
                        <GalleryItem key={session.id} session={session} colors={colors} onDelete={onDeleteSession} />
                    ))
                )}
            </div>
          )}

          {/* Footer Info */}
          <section className="pt-4 border-t border-gray-200/20 mt-8">
             <p className={`text-[10px] ${colors.text} opacity-40 text-center`}>
               Focus Flow v1.4
             </p>
          </section>
        </div>
      </div>
    </>
  );
};
