
import React, { useRef, useEffect, useState } from 'react';
import { Camera, Square, Video, RefreshCw, PictureInPicture2, X, ZoomIn, ZoomOut, Move } from 'lucide-react';
import { ThemeColors, RecordedSession } from '../types';
import { audioService } from '../services/audioService';

interface CameraRecorderProps {
  colors: ThemeColors;
  isHidden: boolean;
  onSaveSession: (session: RecordedSession) => void;
  isPip: boolean;
  onTogglePip: () => void;
  isCompact?: boolean;
}

export const CameraRecorder: React.FC<CameraRecorderProps> = ({ colors, isHidden, onSaveSession, isPip, onTogglePip, isCompact = false }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  
  // Ref for Raw Recording (Video + Mic)
  const rawRecorderRef = useRef<MediaRecorder | null>(null);
  const rawChunksRef = useRef<Blob[]>([]);

  // Ref for Mixed Recording (Video + Mic + Background Noise)
  const mixedRecorderRef = useRef<MediaRecorder | null>(null);
  const mixedChunksRef = useRef<Blob[]>([]);

  // Audio Context for Mixing
  const mixContextRef = useRef<AudioContext | null>(null);
  const mixDestRef = useRef<MediaStreamAudioDestinationNode | null>(null);

  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [streamError, setStreamError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [hasAudio, setHasAudio] = useState(true);

  // Zoom State
  const [zoom, setZoom] = useState(1);
  const [zoomRange, setZoomRange] = useState({ min: 1, max: 10 });
  const [supportsZoom, setSupportsZoom] = useState(true);
  const [showZoomIndicator, setShowZoomIndicator] = useState(false);
  const touchStartDistRef = useRef<number | null>(null);
  const startZoomRef = useRef<number>(1);
  const zoomTimeoutRef = useRef<number | null>(null);

  // Draggable PiP State
  const [pipPos, setPipPos] = useState({ x: 20, y: 20 });
  const [isDragging, setIsDragging] = useState(false);
  const dragOffset = useRef({ x: 0, y: 0 });

  // Initialize PiP position to top-right on mount
  useEffect(() => {
    setPipPos({ x: window.innerWidth - 220, y: 24 });
  }, []);

  useEffect(() => {
    let stream: MediaStream | null = null;

    const startCamera = async () => {
      try {
        if (videoRef.current && videoRef.current.srcObject) {
          const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
          tracks.forEach(track => track.stop());
        }
        
        // Try Video + Audio
        stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
              facingMode: facingMode,
              zoom: true // Request zoom capability
          } as any,
          audio: true 
        });
        
        setHasAudio(true);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.volume = 0; // Mute local playback to prevent feedback
        }
        setStreamError(null);
        checkZoomCapabilities(stream);

      } catch (err) {
        console.warn("Initial camera/mic request failed, retrying video only:", err);
        
        // Fallback: Try Video Only
        try {
            stream = await navigator.mediaDevices.getUserMedia({ 
                video: { 
                    facingMode: facingMode,
                    zoom: true
                } as any,
                audio: false 
            });
            setHasAudio(false);

            if (videoRef.current) {
                videoRef.current.srcObject = stream;
                videoRef.current.volume = 0; 
            }
            setStreamError(null);
            checkZoomCapabilities(stream);
        } catch (videoErr) {
            console.error("Error accessing camera (video only):", videoErr);
            setStreamError("Camera/Mic access denied.");
        }
      }
    };

    if (!isHidden || isPip) { 
      startCamera();
    } else {
      if (videoRef.current && videoRef.current.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach(track => track.stop());
        videoRef.current.srcObject = null;
      }
    }

    return () => {
      if (stream) stream.getTracks().forEach(track => track.stop());
    };
  }, [isHidden, facingMode, isPip]);

  const checkZoomCapabilities = (stream: MediaStream) => {
      const videoTrack = stream.getVideoTracks()[0];
      if (!videoTrack) return;

      const capabilities = (videoTrack as any).getCapabilities ? (videoTrack as any).getCapabilities() : {};
      
      if ('zoom' in capabilities) {
          setSupportsZoom(true);
          setZoomRange({ min: capabilities.zoom.min, max: capabilities.zoom.max });
          const settings = (videoTrack as any).getSettings();
          setZoom(settings.zoom || capabilities.zoom.min);
      } else {
          setSupportsZoom(true); 
      }
  };

  const applyZoom = (value: number) => {
      if (videoRef.current && videoRef.current.srcObject) {
          const track = (videoRef.current.srcObject as MediaStream).getVideoTracks()[0];
          if (track && (track as any).applyConstraints) {
              (track as any).applyConstraints({ advanced: [{ zoom: value }] }).catch((e: any) => console.log("Zoom failed", e));
          }
      }
  };

  const updateZoomWithIndicator = (value: number) => {
    setZoom(value);
    applyZoom(value);
    
    // Show indicator
    setShowZoomIndicator(true);
    if (zoomTimeoutRef.current) {
        window.clearTimeout(zoomTimeoutRef.current);
    }
    zoomTimeoutRef.current = window.setTimeout(() => {
        setShowZoomIndicator(false);
    }, 2000);
  };

  const handleZoomChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const newZoom = parseFloat(e.target.value);
      updateZoomWithIndicator(newZoom);
  };

  // --- Interactions: Drag (PiP) and Zoom (Pinch) ---

  // Mouse Drag (Desktop)
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!isPip) return;
    // Only start drag if clicking background/container, not buttons
    if ((e.target as HTMLElement).closest('button') || (e.target as HTMLElement).closest('input')) return;

    setIsDragging(true);
    dragOffset.current = {
        x: e.clientX - pipPos.x,
        y: e.clientY - pipPos.y
    };
  };

  // Window Mouse listeners for smooth dragging
  useEffect(() => {
    const handleWindowMouseMove = (e: MouseEvent) => {
        if (isDragging) {
            setPipPos({
                x: e.clientX - dragOffset.current.x,
                y: e.clientY - dragOffset.current.y
            });
        }
    };
    const handleWindowMouseUp = () => setIsDragging(false);
    
    if (isDragging) {
        window.addEventListener('mousemove', handleWindowMouseMove);
        window.addEventListener('mouseup', handleWindowMouseUp);
    }
    return () => {
        window.removeEventListener('mousemove', handleWindowMouseMove);
        window.removeEventListener('mouseup', handleWindowMouseUp);
    };
  }, [isDragging]);


  // Touch Interactions
  const handleTouchStart = (e: React.TouchEvent) => {
      // 1. Pinch to Zoom (2 fingers)
      if (e.touches.length === 2 && supportsZoom) {
          const dist = Math.hypot(
              e.touches[0].clientX - e.touches[1].clientX,
              e.touches[0].clientY - e.touches[1].clientY
          );
          touchStartDistRef.current = dist;
          startZoomRef.current = zoom;
      } 
      // 2. Drag PiP (1 finger)
      else if (e.touches.length === 1 && isPip) {
          if ((e.target as HTMLElement).closest('button') || (e.target as HTMLElement).closest('input')) return;
          
          const touch = e.touches[0];
          setIsDragging(true);
          dragOffset.current = {
              x: touch.clientX - pipPos.x,
              y: touch.clientY - pipPos.y
          };
      }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
      // 1. Pinch Zoom
      if (e.touches.length === 2 && touchStartDistRef.current !== null && supportsZoom) {
          const dist = Math.hypot(
              e.touches[0].clientX - e.touches[1].clientX,
              e.touches[0].clientY - e.touches[1].clientY
          );
          
          const scale = dist / touchStartDistRef.current;
          let newZoom = startZoomRef.current * scale;
          newZoom = Math.max(zoomRange.min, Math.min(zoomRange.max, newZoom));
          
          updateZoomWithIndicator(newZoom);
      } 
      // 2. Drag PiP
      else if (e.touches.length === 1 && isPip && isDragging) {
          e.preventDefault(); // Prevent scrolling while dragging
          const touch = e.touches[0];
          setPipPos({
               x: touch.clientX - dragOffset.current.x,
               y: touch.clientY - dragOffset.current.y
          });
      }
  };

  const handleTouchEnd = () => {
      setIsDragging(false);
      touchStartDistRef.current = null;
  };

  // --- Recording Logic ---
  useEffect(() => {
    let interval: number;
    if (isRecording) {
      interval = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  const startRecording = () => {
    if (!videoRef.current || !videoRef.current.srcObject) return;
    const cameraStream = videoRef.current.srcObject as MediaStream;
    
    const rawRecorder = new MediaRecorder(cameraStream, { mimeType: 'video/webm' });
    rawRecorderRef.current = rawRecorder;
    rawChunksRef.current = [];
    rawRecorder.ondataavailable = (e) => { if (e.data.size > 0) rawChunksRef.current.push(e.data); };
    rawRecorder.start(1000);

    try {
        const audioCtx = audioService.initContext();
        if (audioCtx) {
            mixContextRef.current = audioCtx;
            const dest = audioCtx.createMediaStreamDestination();
            mixDestRef.current = dest;
            if (cameraStream.getAudioTracks().length > 0) {
                const micSource = audioCtx.createMediaStreamSource(cameraStream);
                micSource.connect(dest);
            }
            audioService.connectTo(dest);
            const mixedTracks = [
                ...cameraStream.getVideoTracks(),
                ...dest.stream.getAudioTracks()
            ];
            const mixedStream = new MediaStream(mixedTracks);
            const mixedRecorder = new MediaRecorder(mixedStream, { mimeType: 'video/webm' });
            mixedRecorderRef.current = mixedRecorder;
            mixedChunksRef.current = [];
            mixedRecorder.ondataavailable = (e) => { if (e.data.size > 0) mixedChunksRef.current.push(e.data); };
            mixedRecorder.start(1000);
        }
    } catch (e) {
        console.error("Audio mixing failed", e);
    }
    setIsRecording(true);
    setRecordingTime(0);
  };

  const stopRecording = () => {
    if (isRecording) {
      if (rawRecorderRef.current && rawRecorderRef.current.state !== 'inactive') {
        rawRecorderRef.current.stop();
      }
      if (mixedRecorderRef.current && mixedRecorderRef.current.state !== 'inactive') {
        mixedRecorderRef.current.stop();
      }
      setTimeout(() => {
         finishSession();
      }, 500);
      setIsRecording(false);
      if (mixDestRef.current) {
          audioService.disconnectFrom(mixDestRef.current);
          mixDestRef.current = null;
      }
    }
  };

  const finishSession = () => {
      const rawBlob = new Blob(rawChunksRef.current, { type: 'video/webm' });
      let mixedBlob: Blob | null = null;
      if (mixedChunksRef.current.length > 0) {
          mixedBlob = new Blob(mixedChunksRef.current, { type: 'video/webm' });
      }
      let thumbnailUrl = '';
      if (videoRef.current) {
          const canvas = document.createElement('canvas');
          canvas.width = 320;
          canvas.height = 240;
          canvas.getContext('2d')?.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
          thumbnailUrl = canvas.toDataURL('image/jpeg');
      }
      const session: RecordedSession = {
          id: Date.now().toString(),
          timestamp: Date.now(),
          duration: recordingTime,
          rawBlob,
          mixedBlob,
          thumbnailUrl
      };
      onSaveSession(session);
  };

  const toggleCamera = () => {
    setFacingMode(prev => prev === 'user' ? 'environment' : 'user');
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  if (isHidden) return null;

  // Styling Logic
  // Include touchAction: none to prevent browser zooming interference
  const containerStyle: React.CSSProperties = {
    touchAction: 'none',
    ...(isPip 
      ? { position: 'fixed', left: pipPos.x, top: pipPos.y, width: '192px', height: '192px', zIndex: 50 } 
      : {})
  };

  const containerClasses = isPip 
    ? `rounded-3xl shadow-2xl border-4 ${colors.border} overflow-hidden transition-shadow duration-300 ${isDragging ? 'cursor-grabbing scale-105 shadow-3xl' : 'cursor-grab'}`
    : `relative h-full w-full flex flex-col ${colors.secondaryBg} overflow-hidden transition-all duration-700 cubic-bezier(0.4, 0, 0.2, 1)`;

  const videoClasses = isPip
    ? "absolute inset-0 w-full h-full object-cover pointer-events-none" // Pointer events none on video to allow pinch on container
    : `absolute inset-0 w-full h-full object-cover transition-transform duration-500 ${facingMode === 'user' ? 'transform scale-x-[-1]' : ''}`;

  // Determine scaling and layout for compact mode
  // If compact, we might want to adjust padding or font sizes slightly, 
  // but the container resizing handled by flexbox usually does the heavy lifting.
  // The main visual change is handled by App.tsx wrapper. 
  // Here we ensure controls don't get too large.

  return (
    <div 
      className={containerClasses}
      style={containerStyle}
      onMouseDown={handleMouseDown}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <div 
        className="flex-1 relative overflow-hidden bg-black flex items-center justify-center group h-full w-full"
      >
        {streamError ? (
          <div className="text-white p-4 text-center text-xs">
            <p className="mb-2">{streamError}</p>
          </div>
        ) : (
          <video 
            ref={videoRef} 
            autoPlay 
            muted 
            playsInline 
            className={videoClasses} 
          />
        )}
        
        {/* Visual Zoom Indicator */}
        <div className={`absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black/60 backdrop-blur-md text-white px-4 py-2 rounded-full text-xl font-bold pointer-events-none transition-all duration-300 z-40 ${showZoomIndicator ? 'opacity-100 scale-100' : 'opacity-0 scale-90'}`}>
            {zoom.toFixed(1)}x
        </div>

        {/* Overlay UI - Time */}
        <div className={`absolute top-3 left-3 bg-black/60 px-2 py-1 rounded-full flex items-center space-x-2 pointer-events-none z-10 ${isPip ? 'scale-75 origin-top-left' : ''}`}>
            <div className={`w-2 h-2 rounded-full ${isRecording ? 'bg-red-500 animate-pulse' : 'bg-gray-400'}`}></div>
            <span className="text-white text-xs font-mono">{formatTime(recordingTime)}</span>
        </div>

        {/* PiP Toggle Button */}
        <div className="absolute top-3 right-3 z-30 flex gap-2">
            {isPip && (
               <div className="p-2 text-white/50 pointer-events-none"><Move size={14} /></div>
            )}
            <button 
                onClick={onTogglePip} 
                className="p-2 bg-black/50 rounded-full text-white hover:bg-white hover:text-black transition shadow-lg backdrop-blur-sm"
                title={isPip ? "Expand" : "Picture in Picture"}
            >
                {isPip ? <X size={16} /> : <PictureInPicture2 size={16} />}
            </button>
        </div>

        {/* Flip Button */}
        {!isPip && !isRecording && (
          <div className="absolute top-3 right-14 z-20 opacity-0 group-hover:opacity-100 transition-opacity">
              <button 
                onClick={toggleCamera} 
                className="p-2 bg-black/50 rounded-full text-white hover:bg-white hover:text-black transition shadow-lg backdrop-blur-sm"
                title="Switch Camera"
              >
                  <RefreshCw size={16} />
              </button>
          </div>
        )}

        {/* Zoom Controls Slider (Desktop/Visual aid) */}
        {!isPip && supportsZoom && (
            <div className={`absolute right-4 bottom-20 z-20 flex flex-col items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/30 p-2 rounded-xl backdrop-blur-sm ${isCompact ? 'scale-75 origin-bottom-right right-1 bottom-16' : ''}`}>
                 <ZoomIn size={16} className="text-white" />
                 <input 
                    type="range" 
                    min={zoomRange.min} 
                    max={zoomRange.max} 
                    step={0.1} 
                    value={zoom}
                    onChange={handleZoomChange}
                    className="h-32 w-2 bg-gray-400 rounded-lg appearance-none cursor-pointer"
                    style={{ writingMode: 'vertical-lr', WebkitAppearance: 'slider-vertical' } as any}
                 />
                 <ZoomOut size={16} className="text-white" />
            </div>
        )}

        {/* Controls for PiP (Overlay at bottom) */}
        {isPip && (
           <div className="absolute bottom-0 inset-x-0 p-3 bg-gradient-to-t from-black/90 via-black/50 to-transparent flex justify-center z-30">
              {!isRecording ? (
                <button onClick={startRecording} className="p-3 bg-red-600 rounded-full text-white shadow-lg transform hover:scale-110 transition"><Camera size={20} /></button>
              ) : (
                <button onClick={stopRecording} className="p-3 bg-gray-700 rounded-full text-white shadow-lg animate-pulse"><Square size={20} /></button>
              )}
           </div>
        )}
      </div>

      {/* Standard Controls - Compact aware */}
      {!isPip && (
        <div className={`p-3 md:p-4 ${colors.bg} border-t ${colors.border} flex justify-between items-center flex-wrap gap-2 ${isCompact ? 'text-xs p-2' : ''}`}>
            <div className="flex items-center space-x-2">
            <Video size={isCompact ? 16 : 20} className={colors.text} />
            <span className={`font-semibold ${colors.text} ${isCompact ? 'text-xs' : 'text-sm hidden sm:inline'}`}>
                Time Lapse Cam {!hasAudio && <span className="text-[10px] opacity-70 font-normal">(Video Only)</span>}
            </span>
            </div>
            
            <div className="flex space-x-2 md:space-x-3">
            {!isRecording ? (
                <button 
                onClick={startRecording}
                disabled={!!streamError}
                className={`flex items-center rounded-full bg-red-600 text-white hover:bg-red-700 transition disabled:opacity-50 shadow-md hover:shadow-lg transform hover:scale-105 ${isCompact ? 'px-3 py-1 text-xs' : 'px-4 py-2'}`}
                >
                <Camera size={isCompact ? 14 : 16} className="mr-2" />
                Rec
                </button>
            ) : (
                <button 
                onClick={stopRecording}
                className={`flex items-center rounded-full bg-gray-700 text-white hover:bg-gray-600 transition shadow-md animate-pulse ${isCompact ? 'px-3 py-1 text-xs' : 'px-4 py-2'}`}
                >
                <Square size={isCompact ? 14 : 16} className="mr-2 fill-current" />
                Stop
                </button>
            )}
            </div>
        </div>
      )}
    </div>
  );
};
